 <?php
  
  echo '<div id="main">';
  echo '</div>
  <div id="popupbox">';
  
  echo "<div id=\"mastheader\">Javascript Alert <a href=\"javascript:login('hide');enableLinksByElement(main)\"><img align=\"right\" src=\"CloseWindow.gif\"></a>									  </div>	
  Testing Div Popup
  <center><br><p><input onclick=\"javascript:login('hide');enableLinksByElement(main)\"  type=\"button\" value=\"Ok\"></center>
  </div>";
  
 ?>