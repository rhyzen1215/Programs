<?php
$dsn="Queencard";
$server="192.168.254.106";
$database="Queencard";
$user="sa";
$password="P@ssw0rd";
$conn = odbc_connect($dsn,$user,$password);
?>