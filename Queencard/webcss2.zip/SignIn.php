
			<?Php
	
			$LID = $_REQUEST['user'];
			if ($LID != "")
			{
           	include'home.php';
			}
			else
			{
           	include'home.html';
			}
		   	?>   
             
