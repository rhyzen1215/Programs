<?php
$dsn="CIF";
$server="192.168.254.106";
$database="CIF";
$user="sa";
$password="P@ssw0rd";
$conn = odbc_connect($dsn,$user,$password);
?>